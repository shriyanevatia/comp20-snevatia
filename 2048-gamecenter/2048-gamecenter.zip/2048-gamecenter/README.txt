README

Shriya Nevatia
Comp 20
Assignment 4

1. Correctly Implemented: 
	- Downloaded & Modified 2048 files to post data to JSON file
	- Created Heroku page
	- Created git repo
	- Created package.json file
	- Included node_modules in folder
	- Connected MongoDB database to app.js file in node/express app
	- this README

   Incorrectly Implemented: 
   	- Game Manager not displaying
   	- MongoDB not populated with data (therefore cannot get data for JSON)

2. Worked with : Sharada Sant, Krishna Soni, Emma Posamentier

3. Hours spent completing : 15

4. txt format

5. How score is stored in 2048:
	file: game_manager.js
	object: GameManager, called 'score'
   How grid is stored in 2048:
    file: game_manager.js
	object: GameManager, called 'grid'

6. Had to modify game_manager.js and index.html in 2048 source files to send final score and grid to web app.