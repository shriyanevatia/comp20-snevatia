var express = require('express');
var mongo = require('mongodb');
var logfmt = require("logfmt");
var bodyParser = require('body-parser');
var app = express();
var http = require('http');
var path = require('path');
  
// Mongo initialization
var mongoUri = process.env.MONGOLAB_URI || 'mongodb://shriyanevatia:sneva831@ds039717.mongolab.com:39717/shriyanevatia'
  || process.env.MONGOHQ_URL || 'mongodb://localhost/local';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
	db = databaseConnection;
});

// all environments
app.set('port', process.env.PORT || 3000);
app.use(bodyParser());

//app.get('/', routes.index);

app.get('/scores.json', function (req, res){
  mongo.Db.connect(mongoUri, function (err, db){
    db.collection("scores", function (er, col){
      var d = col.find({}).toArray(function(err, x){
        console.log(x);
      });
      col.find({}).sort("created_at").toArray(function(e, x){
        res.send(x);
      });
    });
  });
});

app.post('/submit.json', function (req, res){
  mongo.Db.connect(mongoUri, function (err, db){
    db.collection("scores", function (er, collection){

      var score = parseInt(req.body.score);
      var username = req.body.username;
      var grid = req.body.grid;
      var created_at = parseInt(req.body.created_at);

      collection.insert({"score": score, "username": username, "grid": grid, "created at": created_at}, function (err, r){});
      //res.send("entry loaded");
    });
  });
});

/*
app.post('/submit.json', function(req,res) {
  	res.header("Access-Control-Allow-Origin", "*");
  	res.header("Access-Control-Allow-Headers", "X-Requested-With");
      var entry = req.body;
      var username = entry.username;
      var score = entry.score;
      var grid = entry.grid
      var created_at = "string"
      var collection = db.get('scores');
      collection.insert({
          "username" : username,
          "score" : score,
          "grid" : grid,
          "created_at" : created_at
      }, 
      function (err,doc){
          if(err) { 
      res.send("There was a problem adding the information to the database.")
          }
       }
     );
   }
});
*/

app.get('/', function (req, res){
	db.collection('scores', function(error, collection){
		collection.find().sort({score:-1}).limit(100).toArray(function(error, cursor) 
		{
			if (!error) 
			{
				var index;
				index += "<!DOCTYPE HTML><html><head><title>2048 Game Center</title></head><body><h1>2048 Game Center</h1><table><tr><th>User</th><th>Score</th><th>Timestamp</th><tr>";
				for (var count = 0; count < cursor.length; count++) 
				{
					index += "<tr><td>" + cursor[count].username + "</td><td>" + cursor[count].score + "</td><td>" + cursor[count].created_at + "</td><tr>";
				}
				index += "</table></body></html>";
				res.send(index);
			}
		});
	});
});

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
